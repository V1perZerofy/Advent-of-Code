import java.math.BigInteger;
import java.util.Random;
public class RSA
{
    private Random rnd = new Random();
    private BigInteger p = new BigInteger(30, 99, rnd);
    private BigInteger q = new BigInteger(30, 99, rnd);
    private BigInteger N;
    private BigInteger EulerN;
    private BigInteger e;
    private BigInteger ret;
    private BigInteger otherRet;
    public RSA()
    {
        testPrim(p, q);
        N = p.multiply(q);
        BigInteger eins = new BigInteger("1");
        EulerN = (p.subtract(eins)).multiply(q.subtract(eins));
        e = genE(EulerN);
        if(e.compareTo(eins) == 0) System.out.println("Error!");
        ret = e.modInverse(EulerN);
        otherRet = (ret.multiply(e)).mod(EulerN);
        System.out.println(ret);
        System.out.println(otherRet);
    }
    
    public boolean testPrim(BigInteger p1, BigInteger q1)
    {
        if(p == q) {
            BigInteger p = new BigInteger(30, 99, rnd);
            BigInteger q = new BigInteger(30, 99, rnd);
            testPrim(p, q);
        }
        return true;
    }
    
    private BigInteger genE(BigInteger EulerN1) {
        BigInteger ret = new BigInteger(30, 10, rnd);
        System.out.println(ret);
        if(ret.compareTo(EulerN1) == -1) {
            if((ret.gcd(EulerN1).compareTo(new BigInteger("1")) == 0))return ret;
            genE(EulerN);
        }
        genE(EulerN);
        return new BigInteger("1");
    }
}
